import Frame78 from './imports/Frame78';
import { PhoneMockup } from './components/PhoneMockup';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-gray-100 to-gray-200 flex items-center justify-center p-8">
      <div className="w-full max-w-[500px]">
        {/* Başlık */}
        <div className="text-center mb-8">
          <h1 className="text-gray-800 mb-2">Mobil Önizleme</h1>
          <p className="text-gray-600">Dijital Kartvizit</p>
        </div>

        {/* Telefon Mockup */}
        <PhoneMockup>
          <div className="w-full" style={{ width: '359px', height: 'auto' }}>
            <div style={{ 
              transform: 'scale(0.461)',
              transformOrigin: 'top left',
              width: '779px',
              height: '4579px'
            }}>
              <Frame78 />
            </div>
          </div>
        </PhoneMockup>

        {/* Alt Bilgi */}
        <div className="text-center mt-8 text-gray-500">
          <p>Aşağı kaydırarak tüm içeriği görüntüleyin</p>
        </div>
      </div>
    </div>
  );
}