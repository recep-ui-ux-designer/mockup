import { ReactNode } from 'react';

interface PhoneMockupProps {
  children: ReactNode;
}

export function PhoneMockup({ children }: PhoneMockupProps) {
  return (
    <div className="relative mx-auto" style={{ width: '375px', height: '812px' }}>
      {/* iPhone Çerçevesi */}
      <div className="absolute inset-0 bg-white rounded-[55px] shadow-[0_0_0_12px_#ffffff,0_0_0_13px_#e5e5e5,0_30px_60px_rgba(0,0,0,0.3)]">
        {/* Üst çentik (notch) */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[200px] h-[30px] bg-white rounded-b-[20px] z-10" />
        
        {/* Ekran çentiği - siyah kısım */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[160px] h-[28px] bg-black rounded-b-[18px] z-20 flex items-center justify-center gap-2">
          {/* Hoparlör */}
          <div className="w-[60px] h-[6px] bg-[#1a1a1a] rounded-full" />
          {/* Kamera */}
          <div className="w-[12px] h-[12px] bg-[#1a1a1a] rounded-full border-2 border-[#2a2a2a]" />
        </div>

        {/* Scrollable İçerik Alanı */}
        <div className="absolute top-[35px] left-[8px] right-[8px] bottom-[8px] bg-white rounded-[48px] overflow-hidden">
          <div className="w-full h-full overflow-y-auto overflow-x-hidden scrollbar-custom">
            <div className="w-full min-h-full">
              {children}
            </div>
          </div>
        </div>
      </div>

      {/* Sağ taraf power butonu */}
      <div className="absolute right-[-3px] top-[180px] w-[3px] h-[80px] bg-[#e5e5e5] rounded-r-sm" />
      
      {/* Sol taraf ses butonları */}
      <div className="absolute left-[-3px] top-[140px] w-[3px] h-[30px] bg-[#e5e5e5] rounded-l-sm" />
      <div className="absolute left-[-3px] top-[180px] w-[3px] h-[50px] bg-[#e5e5e5] rounded-l-sm" />
      <div className="absolute left-[-3px] top-[240px] w-[3px] h-[50px] bg-[#e5e5e5] rounded-l-sm" />
    </div>
  );
}
