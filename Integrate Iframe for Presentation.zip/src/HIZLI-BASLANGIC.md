# ⚡ Hızlı Başlangıç Rehberi

## 🎯 5 Dakikada WordPress'e Entegre Edin!

### Adım 1️⃣: Projeyi Deploy Edin (2 dakika)

**Vercel ile (EN KOLAY):**

1. [vercel.com](https://vercel.com) adresine gidin
2. "Sign Up" ile GitHub hesabınızla giriş yapın
3. "Add New Project" butonuna tıklayın
4. Bu projeyi GitHub'a yükleyin veya direkt import edin
5. "Deploy" butonuna tıklayın
6. ✅ Bitti! URL'nizi kopyalayın (örn: `https://mobil-mockup-abc123.vercel.app`)

**Netlify ile:**

1. [netlify.com](https://netlify.com) adresine gidin
2. "Add new site" → "Import an existing project"
3. GitHub repo'nuzu seçin
4. "Deploy site" butonuna tıklayın
5. ✅ URL'nizi kopyalayın

### Adım 2️⃣: WordPress'e Ekleyin (1 dakika)

1. WordPress admin paneline girin
2. Sayfa veya yazı oluşturun/düzenleyin
3. "+" butonuna tıklayıp **"Özel HTML"** bloğunu seçin
4. Aşağıdaki kodu yapıştırın:

```html
<div style="width: 100%; max-width: 500px; margin: 40px auto; padding: 0 20px;">
  <iframe 
    src="BURAYA_DEPLOY_URL_GELİR"
    style="width: 100%; height: 900px; border: none; display: block;"
    title="Mobil Önizleme"
    loading="lazy"
    scrolling="no"
  ></iframe>
</div>
```

5. `BURAYA_DEPLOY_URL_GELİR` yerine Vercel/Netlify URL'nizi yazın
6. ✅ "Yayınla" butonuna tıklayın!

### Adım 3️⃣: Test Edin (1 dakika)

1. Sayfayı tarayıcınızda açın
2. Beyaz telefon mockup'ını görmelisiniz
3. Telefon içinde scroll yaparak tüm içeriği görün
4. ✅ Her şey çalışıyorsa BAŞARILI! 🎉

---

## 🔥 Hızlı İpuçları

### Elementor Kullanıyorsanız

1. Sayfanızı Elementor ile düzenleyin
2. "HTML" widget'ını sürükleyin
3. İframe kodunu yapıştırın
4. Kaydedin ve yayınlayın

### Özel Bir Shortcode İstiyorsanız

WordPress temanızın `functions.php` dosyasına ekleyin:

```php
function mobil_mockup() {
    return '<div style="width:100%;max-width:500px;margin:40px auto;padding:0 20px;">
      <iframe src="https://SIZIN-URL.vercel.app" 
              style="width:100%;height:900px;border:none;" 
              title="Mobil" loading="lazy" scrolling="no"></iframe>
    </div>';
}
add_shortcode('mockup', 'mobil_mockup');
```

Kullanım: Sayfanıza `[mockup]` yazın!

---

## ❓ Sık Karşılaşılan Sorunlar

### ❌ İframe görünmüyor?
✅ **Çözüm:** Deploy URL'nin HTTPS ile başladığından emin olun

### ❌ Scroll çalışmıyor?
✅ **Çözüm:** İframe'de `scrolling="no"` olmalı (içerik kendi içinde scroll olur)

### ❌ Mobilde çok küçük görünüyor?
✅ **Çözüm:** Responsive kod ekleyin:

```html
<style>
  @media (max-width: 768px) {
    .mobil-iframe { height: 700px !important; }
  }
</style>
<iframe class="mobil-iframe" ...></iframe>
```

### ❌ WordPress iframe'i engelliyor?
✅ **Çözüm:** 
1. Yönetici olarak giriş yaptığınızdan emin olun
2. Tema ile çakışma olabilir, farklı tema deneyin
3. Güvenlik eklentilerini kontrol edin (iThemes, Wordfence vb.)

---

## 📞 Acil Yardım

1. **Tarayıcı Konsolu:** `F12` tuşuna basın, hataları görün
2. **Deploy Logları:** Vercel/Netlify panelinden logları kontrol edin
3. **Test Sayfası:** `iframe-ornegi.html` dosyasını tarayıcıda açın

---

## 🎨 Hızlı Özelleştirmeler

### Telefon Rengini Değiştir
`/components/PhoneMockup.tsx` → `bg-white` yerine `bg-black` veya `bg-gray-800`

### Arka Plan Rengini Değiştir
`/App.tsx` → `bg-gradient-to-br from-gray-50 via-gray-100 to-gray-200` değiştirin

### Başlığı Değiştir
`/App.tsx` → `Mobil Önizleme` ve `Dijital Kartvizit` metinlerini değiştirin

---

## ✅ Kontrol Listesi

- [ ] Projeyi Vercel/Netlify'a deploy ettim
- [ ] Deploy URL'mi kopyaladım
- [ ] WordPress'te Özel HTML bloğu oluşturdum
- [ ] İframe kodunu yapıştırdım
- [ ] URL'mi iframe src'ye yazdım
- [ ] Sayfayı yayınladım
- [ ] Test ettim - çalışıyor! 🎉

---

## 🚀 Sonraki Adımlar

1. Farklı cihazlarda test edin (telefon, tablet, desktop)
2. Müşterinize link gönderin
3. Geri bildirim alın
4. Gerekirse özelleştirin

**BAŞARILAR! 🎊**

Daha detaylı bilgi için `README.md` ve `WORDPRESS-ENTEGRASYON.md` dosyalarını okuyun.
