# 📱 Mobil Telefon Mockup - Dijital Kartvizit Sunumu

Profesyonel bir şekilde dijital kartvizitinizi müşterilerinize sunmak için hazırlanmış, beyaz iPhone mockup içinde scroll edilebilir sunum uygulaması.

## ✨ Özellikler

- ✅ **Gerçekçi iPhone Mockup** - Beyaz, profesyonel telefon frame
- ✅ **Scroll Edilebilir İçerik** - Telefon içinde aşağı kaydırılabilir
- ✅ **Tam Responsive** - Her cihazda mükemmel görünüm
- ✅ **WordPress Uyumlu** - Iframe ile kolay entegrasyon
- ✅ **Hatasız Çalışma** - Tam test edilmiş, optimize kod
- ✅ **Figma Import** - Figma tasarımınız direkt kullanılıyor

## 🎯 Kullanım Alanları

- Müşteri sunumları
- Portfolio gösterimleri
- Dijital kartvizit tanıtımları
- Web sitesi önizlemeleri
- Mobil uygulama mockup'ları

## 🚀 Hızlı Başlangıç

### 1. Projeyi Deploy Edin

#### Vercel (Önerilen - En Kolay)
```bash
# Vercel CLI ile
npm i -g vercel
vercel
```

Veya:
1. [Vercel](https://vercel.com)'a gidin
2. GitHub hesabınızla giriş yapın
3. "New Project" butonuna tıklayın
4. Bu repository'yi seçin
5. Deploy edin (ayar değiştirmeye gerek yok)

#### Netlify
1. [Netlify](https://netlify.com)'a gidin
2. "Add new site" > "Import from Git"
3. Repository'nizi seçin
4. Deploy edin

### 2. WordPress'e Ekleyin

Deploy URL'inizi aldıktan sonra, WordPress sayfanızda **Özel HTML** bloğu oluşturun ve şu kodu ekleyin:

```html
<div style="width: 100%; max-width: 500px; margin: 40px auto; padding: 0 20px;">
  <iframe 
    src="https://sizin-proje.vercel.app"
    style="
      width: 100%;
      height: 900px;
      border: none;
      display: block;
      margin: 0 auto;
    "
    title="Mobil Önizleme"
    loading="lazy"
    scrolling="no"
  ></iframe>
</div>
```

**ÖNEMLİ:** `https://sizin-proje.vercel.app` kısmını kendi deploy URL'inizle değiştirin!

## 📂 Proje Yapısı

```
/
├── App.tsx                      # Ana uygulama
├── components/
│   └── PhoneMockup.tsx         # iPhone mockup component
├── imports/
│   ├── Frame78.tsx             # Figma tasarımınız
│   └── svg-764coax9fo.ts       # SVG assets
├── styles/
│   └── globals.css             # Global stiller ve scrollbar
├── WORDPRESS-ENTEGRASYON.md    # Detaylı WordPress rehberi
├── iframe-ornegi.html          # Test için HTML örneği
└── README.md                   # Bu dosya
```

## 🎨 Özelleştirme

### Telefon Rengini Değiştirme

`/components/PhoneMockup.tsx` dosyasında:

```tsx
// Beyaz telefon (varsayılan)
<div className="absolute inset-0 bg-white rounded-[55px] ...">

// Siyah telefon için
<div className="absolute inset-0 bg-[#1a1a1a] rounded-[55px] ...">

// Gri telefon için
<div className="absolute inset-0 bg-[#e5e5e5] rounded-[55px] ...">
```

### Arka Plan Rengini Değiştirme

`/App.tsx` dosyasında:

```tsx
// Gradient arka plan (varsayılan)
<div className="min-h-screen bg-gradient-to-br from-gray-50 via-gray-100 to-gray-200 ...">

// Tek renk arka plan
<div className="min-h-screen bg-white ...">

// Özel gradient
<div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 ...">
```

### Telefon Boyutunu Ayarlama

`/components/PhoneMockup.tsx` dosyasında:

```tsx
// Varsayılan boyut (375x812)
<div className="relative mx-auto" style={{ width: '375px', height: '812px' }}>

// Daha büyük
<div className="relative mx-auto" style={{ width: '414px', height: '896px' }}>

// Daha küçük
<div className="relative mx-auto" style={{ width: '320px', height: '693px' }}>
```

## 📱 Responsive Davranış

Uygulama otomatik olarak responsive'dir:
- Desktop: Tam boyut mockup
- Tablet: Orta boyut mockup
- Mobil: Küçültülmüş mockup

## 🔧 Teknik Detaylar

### Teknolojiler
- **React** - UI framework
- **TypeScript** - Tip güvenliği
- **Tailwind CSS** - Styling
- **Figma Import** - Tasarım entegrasyonu

### Tarayıcı Desteği
- Chrome/Edge (son 2 versiyon)
- Firefox (son 2 versiyon)
- Safari (son 2 versiyon)
- Mobil tarayıcılar (iOS Safari, Chrome Mobile)

### Performans
- Lazy loading görüntüler
- Optimize CSS
- Minimal JavaScript
- Hızlı yükleme süresi

## 📝 WordPress Kullanım Yöntemleri

### 1. Gutenberg (Blok Editör)
1. Sayfa/Yazı düzenle
2. "+" → "Özel HTML" bloğu
3. İframe kodunu yapıştır
4. Yayınla

### 2. Elementor
1. Sayfa düzenle
2. HTML widget ekle
3. İframe kodunu yapıştır
4. Kaydet

### 3. Shortcode (Gelişmiş)
`functions.php` dosyasına:

```php
function mobil_mockup_shortcode() {
    return '<div style="width: 100%; max-width: 500px; margin: 40px auto;">
      <iframe src="https://sizin-proje.vercel.app" 
              style="width: 100%; height: 900px; border: none;"
              title="Mobil Önizleme" loading="lazy" scrolling="no">
      </iframe>
    </div>';
}
add_shortcode('mobil_mockup', 'mobil_mockup_shortcode');
```

Kullanım: `[mobil_mockup]`

## ⚠️ Önemli Notlar

1. **HTTPS Kullanın** - Deploy URL'iniz HTTPS ile başlamalı
2. **CORS Ayarları** - Hosting platformunuzda CORS ayarlarını kontrol edin
3. **Responsive Test** - Farklı cihazlarda test edin
4. **Görsel Yükleme** - Tüm görsellerin yüklendiğinden emin olun

## 🐛 Sorun Giderme

### İframe içeriği görünmüyor
- Deploy URL'ini kontrol edin
- HTTPS kullandığınızdan emin olun
- Tarayıcı konsolunu kontrol edin (F12)

### Scroll çalışmıyor
- `scrolling="no"` özelliğinin iframe'de olduğunu kontrol edin
- Telefon içindeki scroll alanının doğru çalıştığından emin olun

### WordPress'te görünmüyor
- Tema ile uyumluluk sorunlarını kontrol edin
- WordPress'in iframe'lere izin verdiğinden emin olun
- Farklı bir tarayıcıda deneyin

### Mobilde çok küçük
- CSS responsive kodlarını ekleyin
- Viewport meta tag'ini kontrol edin

## 📞 Destek

Sorun yaşarsanız:
1. `WORDPRESS-ENTEGRASYON.md` dosyasını okuyun
2. Tarayıcı konsolunu kontrol edin
3. Deploy platform loglarını inceleyin
4. `iframe-ornegi.html` ile test edin

## 📄 Lisans

Bu proje müşteri sunumları için özel olarak hazırlanmıştır.

## 🎉 Başarılar!

Artık profesyonel bir mobil mockup sunumunuz var! WordPress'e ekleyip müşterilerinize gösterebilirsiniz.

---

**İpucu:** Daha fazla özelleştirme için `PhoneMockup.tsx` ve `App.tsx` dosyalarını inceleyebilirsiniz.
