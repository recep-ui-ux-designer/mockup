import svgPaths from "./svg-764coax9fo";
import img2153484164121731 from "figma:asset/e29e1ef8f45c2bb4ed46a2e54814b081bae9c538.png";
import img9297Recep1 from "figma:asset/dfc6ce054a2656bdafcc2a69ac982a80c95a7504.png";
import imgBlankAluminumCanIsolatedWhiteBackground1 from "figma:asset/b9cc75c28dcb3c4492a9d543038719ccbbc1624a.png";
import img458561 from "figma:asset/db35de327ab05fc24aafdfef4f12f462bfab635e.png";
import imgImage39 from "figma:asset/b1277a4644162affb85f3796a872b8f6f1ec6c7f.png";
import imgImage37 from "figma:asset/f1ba5fe3d767600daa7ec94c502c17da1d06eba4.png";
import imgImage38 from "figma:asset/9de417c4307bfe313aecafa0a2677e19f1bc881c.png";
import imgImage40 from "figma:asset/c1bd08353becb604e5e9e406950f8ca366aa7880.png";
import imgImage41 from "figma:asset/90c2ca593d893243c6ad4aadff209d2d1add1a81.png";
import imgImage42 from "figma:asset/3c9954c729ef46055d492ea4fa0791e037607354.png";

function Component() {
  return (
    <div className="absolute inset-[32.24%_35.44%_66.93%_60.21%]" data-name="_2405633807616">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 39">
        <g id="_2405633807616">
          <path clipRule="evenodd" d={svgPaths.p3c7a2370} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector" />
          <path clipRule="evenodd" d={svgPaths.p2dc87b80} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function LayerX() {
  return (
    <div className="absolute contents inset-[32.24%_35.44%_66.93%_60.21%]" data-name="Layer_x0020_1">
      <Component />
    </div>
  );
}

function Star() {
  return (
    <div className="relative size-[25.163px]" data-name="Star">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 26 26">
        <g id="Star">
          <path d={svgPaths.p2648eff0} fill="var(--fill-0, #FFCB45)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Star1() {
  return (
    <div className="h-[25.163px] relative w-[26.421px]" data-name="Star">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 27 26">
        <g id="Star">
          <path d={svgPaths.pd205fb0} fill="var(--fill-0, #FFCB45)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Star2() {
  return (
    <div className="h-[31.938px] relative w-[33.535px]" data-name="Star">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 32">
        <g id="Star">
          <path d={svgPaths.p64cba00} fill="var(--fill-0, #FFCB45)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Star3() {
  return (
    <div className="relative size-[31.938px]" data-name="Star">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Star">
          <path d={svgPaths.p3453dd00} fill="var(--fill-0, #FFCB45)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

export default function Frame() {
  return (
    <div className="relative size-full">
      <div className="absolute bg-white h-[4579px] left-0 top-0 w-[779px]" />
      <div className="absolute bg-[rgba(255,255,255,0.84)] h-[1592px] left-0 rounded-[50px] shadow-[1px_4px_26.6px_15px_rgba(0,0,0,0.06)] top-0 w-[779px]" />
      <div className="absolute flex h-[255px] items-center justify-center left-0 top-[267px] w-[779px]">
        <div className="flex-none scale-y-[-100%]">
          <div className="bg-[#f4f4f4] h-[255px] w-[779px]" />
        </div>
      </div>
      <div className="absolute h-[296px] left-0 rounded-tl-[50px] rounded-tr-[50px] top-0 w-[779px]" data-name="21534841_6412173 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-tl-[50px] rounded-tr-[50px]">
          <img alt="" className="absolute h-[178.41%] left-0 max-w-none top-[-59.52%] w-[102.16%]" src={img2153484164121731} />
        </div>
      </div>
      <div className="absolute h-[233px] left-[31px] pointer-events-none rounded-[30px] top-[111px] w-[259px]" data-name="9297_recep 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover rounded-[30px] size-full" src={img9297Recep1} />
        <div aria-hidden="true" className="absolute border-[6px] border-solid border-white inset-0 rounded-[30px]" />
      </div>
      <p className="absolute font-['Roboto:Bold',sans-serif] font-bold inset-[3.47%_28.37%_95.5%_40.44%] leading-[1.17] text-[40px] text-center text-white" style={{ fontVariationSettings: "'wdth' 100" }}>
        Recep YILDIZ
      </p>
      <p className="absolute font-['Roboto:Medium',sans-serif] font-medium inset-[4.78%_52.12%_94.45%_40.44%] leading-[1.17] text-[30px] text-[rgba(255,255,255,0.89)] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        CEO
      </p>
      <div className="absolute font-['Be_Vietnam_Pro:Medium',sans-serif] inset-[8.74%_4.75%_89.52%_1.03%] leading-[1.34] not-italic text-[#3d3d3d] text-[30px]">
        <p className="mb-0">X Dijital Kartvizit ile markanı dijitalleştir. Tek tıkla</p>
        <p>paylaşılabilen, modern ve akıllı kartvizit deneyimi.</p>
      </div>
      <div className="absolute bg-[#eff2fc] h-[105px] left-[5px] rounded-[15px] top-[1445px] w-[370px]" />
      <div className="absolute bg-[#3366ff] h-[105px] left-[393px] rounded-[15px] top-[1445px] w-[352px]" />
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[32.28%_14.19%_66.96%_67.07%] leading-[1.17] text-[30px] text-center text-white" style={{ fontVariationSettings: "'wdth' 100" }}>
        Kişiye Ekle
      </p>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[32.32%_68.16%_66.91%_20.28%] leading-[1.17] text-[30px] text-black text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        Paylaş
      </p>
      <LayerX />
      <div className="absolute inset-[32.28%_82.41%_66.87%_12.58%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 39">
          <path d={svgPaths.p348daa00} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[12.64%_60.98%_86.46%_18.23%] leading-[1.17] text-[#14171d] text-[35px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        WhatsApp
      </p>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[15.59%_61.1%_83.51%_18.36%] leading-[1.17] text-[#14171d] text-[35px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        İnstagram
      </p>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[18.74%_62%_80.37%_18.36%] leading-[1.17] text-[#14171d] text-[35px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        Facebook
      </p>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[25.18%_65.73%_73.92%_18.36%] leading-[1.17] text-[#14171d] text-[35px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        E-Posta
      </p>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[21.97%_63.29%_77.13%_18.36%] leading-[1.17] text-[#14171d] text-[35px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        Pinterest
      </p>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[28.48%_66.5%_70.63%_18.49%] leading-[1.17] text-[#14171d] text-[35px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        İletişim
      </p>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[13.69%_52.89%_85.54%_18.49%] leading-[1.17] text-[#6b6b6b] text-[30px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        +905419613679
      </p>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[16.58%_59.18%_82.66%_18.49%] leading-[1.17] text-[#6b6b6b] text-[30px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        Beni Takip Et
      </p>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[19.7%_59.18%_79.54%_18.49%] leading-[1.17] text-[#6b6b6b] text-[30px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        Beni Takip Et
      </p>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[22.93%_59.18%_76.3%_18.49%] leading-[1.17] text-[#6b6b6b] text-[30px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        Beni Takip Et
      </p>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[26.14%_37.61%_73.09%_18.49%] leading-[1.17] text-[#6b6b6b] text-[30px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        destek@xkartvizitler.com
      </p>
      <p className="absolute font-['Roboto:SemiBold',sans-serif] font-semibold inset-[29.44%_52.12%_69.8%_18.49%] leading-[1.17] text-[#6b6b6b] text-[30px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        Adres Bilgileriniz
      </p>
      <div className="absolute inset-[12.49%_83.83%_85.56%_4.88%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 88 89">
          <path clipRule="evenodd" d={svgPaths.pf296c70} fill="var(--fill-0, #3366FF)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[15.51%_83.83%_82.57%_4.88%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 88 88">
          <path clipRule="evenodd" d={svgPaths.p1eed5b00} fill="var(--fill-0, #3366FF)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[18.67%_83.83%_79.36%_4.88%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 88 90">
          <path clipRule="evenodd" d={svgPaths.p353d5f00} fill="var(--fill-0, #3366FF)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[21.84%_83.83%_76.17%_4.88%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 88 91">
          <path clipRule="evenodd" d={svgPaths.p2e96f000} fill="var(--fill-0, #3366FF)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[25.05%_83.83%_73.01%_4.88%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 88 89">
          <path clipRule="evenodd" d={svgPaths.pf296c70} fill="var(--fill-0, #3366FF)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[28.37%_83.83%_69.69%_4.88%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 88 89">
          <path clipRule="evenodd" d={svgPaths.pf296c70} fill="var(--fill-0, #3366FF)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[12.99%_86.78%_86.09%_7.83%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 42 42">
          <path clipRule="evenodd" d={svgPaths.p8e5d380} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[15.96%_86.52%_83.03%_7.57%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46 46">
          <path d={svgPaths.p1921c600} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[19.15%_86.52%_79.84%_7.57%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46 46">
          <path clipRule="evenodd" d={svgPaths.p335bf000} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[25.53%_86.52%_73.53%_7.57%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46 43">
          <path d={svgPaths.p24caecf0} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[22.3%_86.26%_76.61%_7.19%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 51 50">
          <path d={svgPaths.p1c282200} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[28.89%_87.29%_70.19%_8.22%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 35 42">
          <path d={svgPaths.p2a1a9400} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[29.15%_88.83%_70.6%_9.76%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
          <path d={svgPaths.p32f47d00} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute bg-[rgba(255,255,255,0.84)] h-[780px] left-0 rounded-[50px] shadow-[1px_4px_26.6px_15px_rgba(0,0,0,0.06)] top-[2513px] w-[779px]" />
      <div className="absolute h-[636px] left-[61px] rounded-[15px] top-[2604px] w-[689px]" data-name="blank-aluminum-can-isolated-white-background 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[15px]">
          <img alt="" className="absolute h-full left-[-22.04%] max-w-none top-0 w-[138.47%]" src={imgBlankAluminumCanIsolatedWhiteBackground1} />
        </div>
      </div>
      <div className="absolute flex h-[46.558px] items-center justify-center left-[319px] top-[2541px] w-[128.539px]" style={{ "--transform-inner-width": "133", "--transform-inner-height": "38" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.301deg]">
          <p className="font-['Roboto:Bold',sans-serif] font-bold leading-[100.085%] relative text-[#050504] text-[38px] text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
            Portföy
          </p>
        </div>
      </div>
      <div className="absolute flex h-[45.34px] items-center justify-center left-[348.01px] top-[2873px] w-[107.143px]" style={{ "--transform-inner-width": "128.78125", "--transform-inner-height": "38" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.818deg]">
          <p className="font-['Roboto:Black',sans-serif] font-black leading-[100.085%] relative text-[38px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
            Başlık
          </p>
        </div>
      </div>
      <div className="absolute flex h-[47.528px] items-center justify-center left-[316.01px] top-[2934.55px] w-[166.149px]" style={{ "--transform-inner-width": "164.5", "--transform-inner-height": "40" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.818deg]">
          <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[100.085%] relative text-[40px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
            Açıklama
          </p>
        </div>
      </div>
      <div className="absolute bg-[rgba(255,255,255,0.84)] h-[855px] left-0 rounded-[50px] shadow-[0px_1px_26.6px_15px_rgba(0,0,0,0.06)] top-[1622px] w-[779px]" />
      <div className="absolute flex h-[48.753px] items-center justify-center left-[231px] top-[1632px] w-[308.526px]" style={{ "--transform-inner-width": "323.09375", "--transform-inner-height": "38" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.301deg]">
          <p className="font-['Roboto:Bold',sans-serif] font-bold leading-[100.085%] relative text-[#050504] text-[38px] text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
            Ürün ve Hizmetler
          </p>
        </div>
      </div>
      <div className="absolute flex h-[755.481px] items-center justify-center left-[27px] top-[1687.24px] w-[715.712px]" style={{ "--transform-inner-width": "714.015625", "--transform-inner-height": "753.875" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.871deg]">
          <div className="h-[753.875px] relative rounded-[15px] w-[714.016px]">
            <div aria-hidden="true" className="absolute border-4 border-[rgba(230,230,230,0.62)] border-solid inset-0 pointer-events-none rounded-[15px]" />
          </div>
        </div>
      </div>
      <div className="absolute flex h-[45.236px] items-center justify-center left-[53px] top-[2198px] w-[105.101px]" style={{ "--transform-inner-width": "111.96875", "--transform-inner-height": "38" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.871deg]">
          <p className="font-['Roboto:Bold',sans-serif] font-bold leading-[100.085%] relative text-[#050504] text-[38px] text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
            Başlık
          </p>
        </div>
      </div>
      <div className="absolute flex h-[43.189px] items-center justify-center left-[53px] top-[2265px] w-[84.097px]" style={{ "--transform-inner-width": "77.875", "--transform-inner-height": "35" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.871deg]">
          <p className="font-['Righteous:Regular','Noto_Sans:Regular',sans-serif] leading-[100.085%] relative text-[#3366ff] text-[35px] text-nowrap whitespace-pre" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
            250₺
          </p>
        </div>
      </div>
      <div className="absolute flex h-[33.239px] items-center justify-center left-[53px] top-[2334px] w-[106.074px]" style={{ "--transform-inner-width": "102.8125", "--transform-inner-height": "25" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.871deg]">
          <p className="font-['Rethink_Sans:Regular',sans-serif] font-normal leading-[100.085%] relative text-[#3d3d3d] text-[25px] text-nowrap whitespace-pre">Açıklama</p>
        </div>
      </div>
      <div className="absolute flex h-[29.453px] items-center justify-center left-[53px] top-[2393px] w-[201.065px]" style={{ "--transform-inner-width": "204.28125", "--transform-inner-height": "25" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.871deg]">
          <p className="font-['Roboto:Medium',sans-serif] font-medium leading-[100.085%] relative text-[#3366ff] text-[25px] text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
            Daha Fazla Bigi Al
          </p>
        </div>
      </div>
      <div className="absolute flex inset-[52.37%_62.77%_47.19%_34.27%] items-center justify-center">
        <div className="flex-none h-[20.133px] rotate-[359.871deg] w-[23.009px]">
          <div className="relative size-full" data-name="Vector">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23 21">
              <path d={svgPaths.pa203180} fill="var(--fill-0, #3366FF)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute h-[500px] left-[61px] top-[1707px] w-[682px]" data-name="45856 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[124.58%] left-[-21.4%] max-w-none top-[-13.55%] w-[137.09%]" src={img458561} />
        </div>
      </div>
      <div className="absolute left-[94px] rounded-[320px] size-[94px] top-[4026px]" data-name="image 39">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none rounded-[320px] size-full" src={imgImage39} />
      </div>
      <div className="absolute bg-[rgba(255,255,255,0.84)] h-[1250px] left-0 rounded-[50px] shadow-[1px_4px_26.6px_15px_rgba(0,0,0,0.06)] top-[3329px] w-[774px]" />
      <div className="absolute flex h-[48.616px] items-center justify-center left-[291.14px] top-[3379px] w-[198.79px]" style={{ "--transform-inner-width": "209.125", "--transform-inner-height": "38" } as React.CSSProperties}>
        <div className="flex-none rotate-[358.952deg]">
          <p className="font-['Roboto:Bold',sans-serif] font-bold leading-[100.085%] relative text-[#050504] text-[38px] text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
            Referanslar
          </p>
        </div>
      </div>
      <p className="absolute font-['Roboto:Bold',sans-serif] font-bold leading-[100.085%] left-[205px] text-[#050504] text-[30px] text-nowrap top-[3800px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Semiha YILDIZ
      </p>
      <p className="absolute font-['Roboto:Bold',sans-serif] font-bold leading-[100.085%] left-[205px] text-[#050504] text-[30px] text-nowrap top-[3919px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Aylin Oğuz
      </p>
      <p className="absolute font-['Roboto:Bold',sans-serif] font-bold leading-[100.085%] left-[205px] text-[#050504] text-[30px] text-nowrap top-[4046px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Muhammet KURU
      </p>
      <p className="absolute font-['Roboto:Bold',sans-serif] font-bold leading-[100.085%] left-[205px] text-[#050504] text-[30px] text-nowrap top-[4165px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        İbrahim TAŞ
      </p>
      <p className="absolute font-['Roboto:Bold',sans-serif] font-bold leading-[100.085%] left-[205px] text-[#050504] text-[30px] text-nowrap top-[4293px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Selda OĞUZ
      </p>
      <p className="absolute font-['Roboto:Bold',sans-serif] font-bold leading-[100.085%] left-[205px] text-[#050504] text-[30px] text-nowrap top-[4412px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Ensar ŞİMŞEK
      </p>
      <div className="absolute flex h-[33.253px] items-center justify-center left-[202px] top-[3841px] w-[106.079px]" style={{ "--transform-inner-width": "102.8125", "--transform-inner-height": "25" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.863deg]">
          <p className="font-['Rethink_Sans:Regular',sans-serif] font-normal leading-[100.085%] relative text-[#3d3d3d] text-[25px] text-nowrap whitespace-pre">Açıklama</p>
        </div>
      </div>
      <div className="absolute flex h-[29.709px] items-center justify-center left-[129px] top-[3579px] w-[66.308px]" style={{ "--transform-inner-width": "76.40625", "--transform-inner-height": "25" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.383deg]">
          <p className="font-['Roboto:Bold',sans-serif] font-bold leading-[100.085%] relative text-[#585858] text-[25px] text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>{`Demo `}</p>
        </div>
      </div>
      <div className="absolute flex h-[33.253px] items-center justify-center left-[202px] top-[3960px] w-[106.079px]" style={{ "--transform-inner-width": "102.8125", "--transform-inner-height": "25" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.863deg]">
          <p className="font-['Rethink_Sans:Regular',sans-serif] font-normal leading-[100.085%] relative text-[#3d3d3d] text-[25px] text-nowrap whitespace-pre">Açıklama</p>
        </div>
      </div>
      <div className="absolute flex h-[33.253px] items-center justify-center left-[202px] top-[4087px] w-[106.079px]" style={{ "--transform-inner-width": "102.8125", "--transform-inner-height": "25" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.863deg]">
          <p className="font-['Rethink_Sans:Regular',sans-serif] font-normal leading-[100.085%] relative text-[#3d3d3d] text-[25px] text-nowrap whitespace-pre">Açıklama</p>
        </div>
      </div>
      <div className="absolute flex h-[33.253px] items-center justify-center left-[202px] top-[4206px] w-[106.079px]" style={{ "--transform-inner-width": "102.8125", "--transform-inner-height": "25" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.863deg]">
          <p className="font-['Rethink_Sans:Regular',sans-serif] font-normal leading-[100.085%] relative text-[#3d3d3d] text-[25px] text-nowrap whitespace-pre">Açıklama</p>
        </div>
      </div>
      <div className="absolute flex h-[33.253px] items-center justify-center left-[202px] top-[4334px] w-[106.079px]" style={{ "--transform-inner-width": "102.8125", "--transform-inner-height": "25" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.863deg]">
          <p className="font-['Rethink_Sans:Regular',sans-serif] font-normal leading-[100.085%] relative text-[#3d3d3d] text-[25px] text-nowrap whitespace-pre">Açıklama</p>
        </div>
      </div>
      <div className="absolute h-[307px] left-[96px] rounded-[15px] top-[3443px] w-[599px]">
        <div aria-hidden="true" className="absolute border-[3px] border-[rgba(230,230,230,0.62)] border-solid inset-0 pointer-events-none rounded-[15px]" />
      </div>
      <div className="absolute flex h-[69.139px] items-center justify-center left-[130px] top-[3408px] w-[73.794px]" style={{ "--transform-inner-width": "72.625", "--transform-inner-height": "67.890625" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.015deg]">
          <div className="bg-[#3366ff] h-[67.901px] rounded-[10px] shadow-[0px_5px_5px_0px_rgba(51,102,255,0.41)] w-[72.638px]" />
        </div>
      </div>
      <div className="absolute flex h-[91.502px] items-center justify-center left-[149px] top-[3420px] w-[36.326px]" style={{ "--transform-inner-width": "44.453125", "--transform-inner-height": "80" } as React.CSSProperties}>
        <div className="flex-none rotate-[0.837deg]">
          <p className="font-['Rokkitt:Black',sans-serif] font-black leading-[100.085%] relative text-[80px] text-nowrap text-white whitespace-pre">‘‘</p>
        </div>
      </div>
      <div className="absolute flex items-center justify-center left-[203.36px] size-[25.291px] top-[3609.18px]" style={{ "--transform-inner-width": "25.15625", "--transform-inner-height": "25.15625" } as React.CSSProperties}>
        <div className="flex-none rotate-[0.291deg]">
          <Star />
        </div>
      </div>
      <div className="absolute flex h-[25.297px] items-center justify-center left-[237.33px] top-[3609.35px] w-[26.549px]" style={{ "--transform-inner-width": "26.40625", "--transform-inner-height": "25.15625" } as React.CSSProperties}>
        <div className="flex-none rotate-[0.291deg]">
          <Star1 />
        </div>
      </div>
      <div className="absolute flex items-center justify-center left-[272.56px] size-[25.291px] top-[3609.53px]" style={{ "--transform-inner-width": "25.15625", "--transform-inner-height": "25.15625" } as React.CSSProperties}>
        <div className="flex-none rotate-[0.291deg]">
          <Star />
        </div>
      </div>
      <div className="absolute flex h-[25.297px] items-center justify-center left-[306.53px] top-[3609.71px] w-[26.549px]" style={{ "--transform-inner-width": "26.40625", "--transform-inner-height": "25.15625" } as React.CSSProperties}>
        <div className="flex-none rotate-[0.291deg]">
          <Star1 />
        </div>
      </div>
      <div className="absolute flex h-[57.9px] items-center justify-center left-[29px] top-[3566px] w-[59.716px]" style={{ "--transform-inner-width": "47.828125", "--transform-inner-height": "44.921875" } as React.CSSProperties}>
        <div className="flex-none rotate-[341.294deg]">
          <div className="h-[44.933px] relative w-[47.832px]">
            <div className="absolute inset-[-0.22%_-10.66%_-22.48%_-10.66%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 59 56">
                <g filter="url(#filter0_d_1_234)" id="Ellipse 463">
                  <ellipse cx="29.0162" cy="22.5667" fill="var(--fill-0, white)" rx="23.9162" ry="22.4667" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="55.1334" id="filter0_d_1_234" width="58.0324" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
                    <feOffset dy="5" />
                    <feGaussianBlur stdDeviation="2.55" />
                    <feComposite in2="hardAlpha" operator="out" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.11 0" />
                    <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_234" />
                    <feBlend in="SourceGraphic" in2="effect1_dropShadow_1_234" mode="normal" result="shape" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[57.325px] items-center justify-center left-[703px] top-[3567.71px] w-[59.208px]" style={{ "--transform-inner-width": "47.828125", "--transform-inner-height": "44.921875" } as React.CSSProperties}>
        <div className="flex-none rotate-[342.343deg]">
          <div className="h-[44.933px] relative w-[47.832px]">
            <div className="absolute inset-[-0.22%_-10.66%_-22.48%_-10.66%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 59 56">
                <g filter="url(#filter0_d_1_232)" id="Ellipse 464">
                  <ellipse cx="29.0162" cy="22.5667" fill="var(--fill-0, white)" rx="23.9162" ry="22.4667" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="55.1334" id="filter0_d_1_232" width="58.0324" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
                    <feOffset dy="5" />
                    <feGaussianBlur stdDeviation="2.55" />
                    <feComposite in2="hardAlpha" operator="out" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.11 0" />
                    <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_232" />
                    <feBlend in="SourceGraphic" in2="effect1_dropShadow_1_232" mode="normal" result="shape" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[18.836px] items-center justify-center left-[51.64px] top-[3587.1px] w-[17.489px]" style={{ "--transform-inner-width": "12.65625", "--transform-inner-height": "15.140625" } as React.CSSProperties}>
        <div className="flex-none rotate-[337.562deg]">
          <div className="h-[15.148px] relative w-[12.666px]">
            <div className="absolute inset-[-9.9%_-11.85%_-9.9%_-11.84%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 19">
                <path d={svgPaths.pa1cfa00} id="Vector 10" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[18.856px] items-center justify-center left-[722.92px] top-[3587.37px] w-[17.521px]" style={{ "--transform-inner-width": "12.65625", "--transform-inner-height": "15.140625" } as React.CSSProperties}>
        <div className="flex-none rotate-[157.364deg]">
          <div className="h-[15.148px] relative w-[12.666px]">
            <div className="absolute inset-[-9.9%_-11.85%_-9.9%_-11.84%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 19">
                <path d={svgPaths.pa1cfa00} id="Vector 11" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[32.108px] items-center justify-center left-[129px] top-[3685px] w-[33.697px]" style={{ "--transform-inner-width": "33.53125", "--transform-inner-height": "31.9375" } as React.CSSProperties}>
        <div className="flex-none rotate-[0.291deg]">
          <Star2 />
        </div>
      </div>
      <div className="absolute flex items-center justify-center left-[173.7px] size-[32.1px] top-[3685.23px]" style={{ "--transform-inner-width": "31.9375", "--transform-inner-height": "31.9375" } as React.CSSProperties}>
        <div className="flex-none rotate-[0.291deg]">
          <Star3 />
        </div>
      </div>
      <div className="absolute flex h-[32.108px] items-center justify-center left-[216.82px] top-[3685.45px] w-[33.697px]" style={{ "--transform-inner-width": "33.53125", "--transform-inner-height": "31.9375" } as React.CSSProperties}>
        <div className="flex-none rotate-[0.291deg]">
          <Star2 />
        </div>
      </div>
      <div className="absolute flex items-center justify-center left-[261.54px] size-[32.1px] top-[3685.67px]" style={{ "--transform-inner-width": "31.9375", "--transform-inner-height": "31.9375" } as React.CSSProperties}>
        <div className="flex-none rotate-[0.291deg]">
          <Star3 />
        </div>
      </div>
      <div className="absolute flex h-[32.108px] items-center justify-center left-[304.65px] top-[3685.89px] w-[33.697px]" style={{ "--transform-inner-width": "33.53125", "--transform-inner-height": "31.9375" } as React.CSSProperties}>
        <div className="flex-none rotate-[0.291deg]">
          <Star2 />
        </div>
      </div>
      <div className="absolute left-[98px] rounded-[320px] size-[89px] top-[3794px]" data-name="image 37">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none rounded-[320px] size-full" src={imgImage37} />
      </div>
      <div className="absolute left-[98px] rounded-[320px] size-[90px] top-[3914px]" data-name="image 38">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none rounded-[320px] size-full" src={imgImage38} />
      </div>
      <div className="absolute left-[96px] rounded-[50px] size-[93px] top-[4161px]" data-name="image 40">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none rounded-[50px] size-full" src={imgImage40} />
      </div>
      <div className="absolute left-[96px] rounded-[320px] size-[93px] top-[4284px]" data-name="image 41">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none rounded-[320px] size-full" src={imgImage41} />
      </div>
      <div className="absolute left-[96px] rounded-[320px] size-[95px] top-[4407px]" data-name="image 42">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none rounded-[320px] size-full" src={imgImage42} />
      </div>
    </div>
  );
}