# WordPress İframe Entegrasyon Rehberi

Bu rehber, mobil telefon mockup sunumunuzu WordPress sayfasına nasıl entegre edeceğinizi adım adım açıklar.

## 📱 Özellikler
- ✅ Profesyonel beyaz iPhone mockup
- ✅ Scroll edilebilir içerik
- ✅ Responsive tasarım
- ✅ Tam hata kontrolü
- ✅ WordPress uyumlu iframe yapısı

## 🚀 WordPress'e Entegrasyon Adımları

### Adım 1: Uygulamanızı Yayınlayın
1. Bu projeyi bir hosting hizmetine deploy edin (örn: Vercel, Netlify, GitHub Pages)
2. Deploy edildikten sonra size verilen URL'i kopyalayın (örn: `https://sizin-proje.vercel.app`)

### Adım 2: WordPress Sayfanıza İframe Kodu Ekleyin

WordPress sayfanızda **HTML bloğu** veya **Özel HTML** widget'ı kullanarak aşağıdaki kodu ekleyin:

```html
<!-- Mobil Telefon Mockup İframe -->
<div style="width: 100%; max-width: 500px; margin: 40px auto; padding: 0 20px;">
  <iframe 
    src="BURAYA_DEPLOY_URL_GELECEK"
    style="
      width: 100%;
      height: 900px;
      border: none;
      display: block;
      margin: 0 auto;
    "
    title="Mobil Önizleme"
    loading="lazy"
    scrolling="no"
  ></iframe>
</div>
```

**ÖNEMLİ:** `BURAYA_DEPLOY_URL_GELECEK` yazan yeri kendi deploy URL'inizle değiştirin!

### Adım 3: Tam Sayfa Versiyon (Opsiyonel)

Eğer sunumun tam sayfa olmasını istiyorsanız:

```html
<!-- Tam Sayfa Mockup -->
<div style="width: 100%; min-height: 100vh; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); padding: 40px 20px;">
  <iframe 
    src="BURAYA_DEPLOY_URL_GELECEK"
    style="
      width: 100%;
      max-width: 500px;
      height: 950px;
      border: none;
      display: block;
      margin: 0 auto;
      box-shadow: 0 20px 60px rgba(0,0,0,0.15);
      border-radius: 20px;
      background: white;
    "
    title="Dijital Kartvizit Önizleme"
    loading="lazy"
    scrolling="no"
  ></iframe>
</div>
```

## 📋 WordPress Kullanım Yöntemleri

### Yöntem 1: Gutenberg Editör (Blok Editör)
1. Sayfanızı düzenleyin
2. "+" butonuna tıklayın
3. "Özel HTML" bloğunu seçin
4. Yukarıdaki iframe kodunu yapıştırın
5. "Yayınla" veya "Güncelle" butonuna tıklayın

### Yöntem 2: Klasik Editör
1. Sayfanızı düzenleyin
2. Editörde "Metin" (Text) sekmesine geçin
3. Yukarıdaki iframe kodunu yapıştırın
4. "Yayınla" veya "Güncelle" butonuna tıklayın

### Yöntem 3: Elementor (Page Builder)
1. Sayfanızı Elementor ile düzenleyin
2. "HTML" widget'ını sürükleyin
3. Yukarıdaki iframe kodunu yapıştırın
4. Kaydedin ve yayınlayın

### Yöntem 4: Shortcode Oluşturma
WordPress temanızın `functions.php` dosyasına ekleyin:

```php
function mobil_mockup_shortcode() {
    return '
    <div style="width: 100%; max-width: 500px; margin: 40px auto; padding: 0 20px;">
      <iframe 
        src="BURAYA_DEPLOY_URL_GELECEK"
        style="
          width: 100%;
          height: 900px;
          border: none;
          display: block;
          margin: 0 auto;
        "
        title="Mobil Önizleme"
        loading="lazy"
        scrolling="no"
      ></iframe>
    </div>';
}
add_shortcode('mobil_mockup', 'mobil_mockup_shortcode');
```

Daha sonra sayfanızda şu kodu kullanın:
```
[mobil_mockup]
```

## 🎨 Özelleştirme Seçenekleri

### Iframe Boyutunu Ayarlama
```html
<!-- Daha küçük versiyon -->
<iframe ... style="height: 800px; ..."></iframe>

<!-- Daha büyük versiyon -->
<iframe ... style="height: 1000px; ..."></iframe>
```

### Responsive Yapı
```html
<style>
  @media (max-width: 768px) {
    .mockup-iframe {
      height: 700px !important;
    }
  }
</style>

<iframe 
  class="mockup-iframe"
  src="..."
  style="height: 900px; ..."
></iframe>
```

## 🔒 Güvenlik İpuçları

1. **HTTPS Kullanın:** Deploy URL'inizin HTTPS ile başladığından emin olun
2. **CSP Headers:** Hosting platformunuzda Content Security Policy ayarlarını kontrol edin
3. **CORS Ayarları:** İframe'in düzgün çalışması için CORS ayarlarının doğru olduğundan emin olun

## 📱 Mobil Uyumluluk

İframe otomatik olarak responsive'dir, ancak daha iyi mobil deneyim için:

```html
<div style="width: 100%; max-width: 500px; margin: 40px auto; padding: 0 20px;">
  <iframe 
    src="BURAYA_DEPLOY_URL_GELECEK"
    style="
      width: 100%;
      height: 700px;
      border: none;
      display: block;
      margin: 0 auto;
    "
    class="responsive-mockup"
    title="Mobil Önizleme"
    loading="lazy"
    scrolling="no"
  ></iframe>
</div>

<style>
  @media (min-width: 768px) {
    .responsive-mockup {
      height: 900px !important;
    }
  }
</style>
```

## ⚡ Deploy Seçenekleri

### Vercel (Önerilen)
1. GitHub'a projeyi yükleyin
2. Vercel.com'a gidin
3. "New Project" > GitHub repo'nuzu seçin
4. Deploy edin
5. Verilen URL'i kopyalayın

### Netlify
1. Netlify.com'a gidin
2. "Add new site" > GitHub'dan import edin
3. Deploy edin
4. Verilen URL'i kopyalayın

### GitHub Pages
1. Repo ayarlarından Pages'i aktifleştirin
2. Branch olarak `main` seçin
3. Deploy URL'i `https://kullanici.github.io/repo-adi` olacaktır

## 🎯 Test Etme

1. İframe kodunu WordPress'e ekledikten sonra önizleme yapın
2. Sayfayı farklı cihazlarda test edin (mobil, tablet, desktop)
3. Scroll fonksiyonunun çalıştığını kontrol edin
4. Tüm görsellerin yüklendiğini doğrulayın

## ❓ Sık Sorulan Sorular

**S: İframe içeriği görünmüyor?**
C: Deploy URL'inizi kontrol edin, HTTPS kullandığınızdan emin olun.

**S: Scroll çalışmıyor?**
C: İframe'in `scrolling="no"` olduğundan emin olun (içerik kendi içinde scroll edilir).

**S: Mobilde çok küçük görünüyor?**
C: Yukarıdaki responsive kod örneğini kullanın.

**S: WordPress iframe'i engelliyor?**
C: WordPress admin panelinden "Ayarlar > Okuma" kısmında iframe izinlerini kontrol edin.

## 📞 Destek

Herhangi bir sorunla karşılaşırsanız:
1. Tarayıcı konsolunu kontrol edin (F12)
2. Deploy platformunuzun loglarını inceleyin
3. WordPress tema uyumluluğunu kontrol edin

---

**Başarılar! 🎉** 

Bu mockup sunum aracı ile müşterilerinize profesyonel bir deneyim sunacaksınız.
